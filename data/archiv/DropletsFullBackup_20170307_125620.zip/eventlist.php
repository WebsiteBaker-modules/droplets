//:Shows an event list from procalendar >= 1.3
//:usage: [[eventlist?section_id=<xx>&max=<xx>&kat=<xx>,<xx>&days=<xx>&year=<xx>&month=<xx>&startnow=1]]
//
// Shows an event list from procalendar >= 1.3
// usage: [[eventlist?section_id=<xx>&max=<xx>&kat=<xx>,<xx>&days=<xx>&year=<xx>&month=<xx>&startnow=1]]
// parameters:
//   section_id : Section id from procalendar module
//     on default all events of the current month are shown but you can custumize by using options:
//   max (integer) 	: limits event list to max items (if no other limit is reached already)
//   kat (integer) 	: only show defined kategories, kat ids can be found in prcalendar backend options
//			  more than one kategorie can be used by seperating ids with commas (no spaces) 
//   days (integer) : limits event list to items for <days> (if no other limit is reached already)
//   year (integer) : year of start date
//   month (integer): month of start date
//   dateformat (string): format of date representation as described in http://www.php.net/manual/en/function.date.php#refsect1-function.date-parameters
//   startnow (0/1) : 0 or not set = show calendar month, 1 = start at current day

global $database;
require_once(WB_PATH."/modules/procalendar/functions.php");
$mod_list = '';
$startnow = isset($startnow) ?  intval($startnow) : 0;
$max = isset($max) ? intval($max) : 10000;
$fixdays = isset($days);
$days = isset($days) ? intval($days) : 31;
$year = isset($year) ? intval ($year) : date('Y');
$month = isset($month) ? intval($month) : date('n');
$section_id = isset($section_id) ? intval($section_id) : 0 ;

// Set dateformat to suit your needs, add timeformat if needed
$dateformat = isset($dateformat) ? $dateformat : 'd.m. H:i'; // Standard php date formats 'd-m-Y'

// Fetch base page link
$page_id = 0;
$page_link ='';

if ($section_id<>0) {
$sql = "SELECT link FROM ".TABLE_PREFIX."sections AS s, ".TABLE_PREFIX."pages AS p WHERE s.section_id = '".$section_id."' AND s.page_id = p.page_id";
$page_link = WB_URL.PAGES_DIRECTORY.$database->get_one($sql).PAGE_EXTENSION;
}

// Set start- and end date for query
$datestart = $startnow ? date('Y-n-j') : "$year-$month-1";
$dateend = $startnow ? date('Y-n-j', strtotime("+".($days-1)." day")) : $fixdays ? date('Y-n-j', strtotime($datestart." + ".($days-1)." day")) : "$year-$month-".($days < cal_days_in_month(CAL_GREGORIAN, $month,$year) ? $days : cal_days_in_month(CAL_GREGORIAN, $month,$year));

if (isset($archive)) {
$dateend = date('Y-n-j');
$datestart = date('Y-n-j', strtotime("-".($days-1)." day"));
}

$mod_list .= "<div class='info_body' style='text-align:left'>";

// Fetch the items
if (!isset($actions) || empty($actions))
$actions  = fillActionArray($datestart, $dateend, $section_id);

if (is_array($actions)){
foreach($actions as $row){
if ($max > 0) {
if (!isset($kat) || (isset($kat) && in_array($row["acttype"], explode(',',$kat)))) {
$max--;
$ds = $row['date_start']." ".substr($row['time_start'],0,5);
$de = $row['date_end']." ".substr($row['time_end'],0,5);
// Build url like : pages/kalendar.php?year=1900&month=01&day=03&id=2&detail=1
$page_url = $page_link.'?year='.(substr($ds,0,4)).'&month='.(substr($ds,5,2)).'&day='.(substr($ds,8,2)).'&id='.$row['id'].'&detail=1';
$datetime_start = mktime(substr($ds,11,2),substr($ds,14,2),0,substr($ds,5,2),substr($ds,8,2),substr($ds,0,4));
$datetime_end = mktime(substr($de,11,2),substr($de,14,2),0,substr($de,5,2),substr($de,8,2),substr($de,0,4));
if ($datetime_start<> $datetime_end) {
$mod_list .= '<tr style="background-color: '.$row["act_format"].'"><td><span class="c_date">'.date($dateformat,$datetime_start).'</span>  </td> ';
} else {
$mod_list .= '<tr style="background-color: '.$row["act_format"].'"><td><span class="c_date">'.date($dateformat,$datetime_start).'</span>  </td> ';
}
$mod_list .= '<td><a href="'.$page_url.'"><span class="c_name"><b>'.$row["name"].'</b></span></a></td>';
$mod_list .= '<td><div class="c_desc">'.$row["custom1"].'</div></td>';
$mod_list .= "</tr>";
}
}
}
}
return $mod_list .= "</div>";