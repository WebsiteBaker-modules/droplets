//:zeigt das aktuelle Jahr an
//:[[year]] zeigt die Jahrezahl
$datum = date("Y");
return "$datum";